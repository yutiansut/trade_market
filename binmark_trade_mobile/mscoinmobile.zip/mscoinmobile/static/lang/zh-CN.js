module.exports = {
    login: "登录"
}