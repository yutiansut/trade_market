module.exports = {
    login: "Login"
}